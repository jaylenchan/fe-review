<template>
  <div>
    <el-button type="primary">fjfiafj</el-button>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'dd',
  setup() {
    console.log('dd')
  }
})
</script>

<style scoped></style>
